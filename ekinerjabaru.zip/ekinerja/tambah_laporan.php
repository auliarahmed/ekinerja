<?php
session_start();
if($_SESSION['status']!="login"){
    header("location:index.php?pesan=belum_login");
}
date_default_timezone_set('Asia/Makassar');
// koneksi database
include 'koneksi.php';
// menangkap data yang di kirim dari form
$level = $_SESSION['level'];
$kegiatan = $_POST['kegiatan'];
$uraian = $_POST['uraian'];
$tgl_server = date("Y-m-d H:i:s");
$waktu = $_POST['waktu'];
$tgl_input = date("Y-m-d", strtotime($_POST['tgl_input']));
// menginput data ke database
mysqli_query($koneksi,"insert into tb_laporan values('','$level','$kegiatan','$uraian','$tgl_server','T','$waktu','$tgl_input')");
// mengalihkan halaman kembali ke index.php
header("location:form.php");
?>